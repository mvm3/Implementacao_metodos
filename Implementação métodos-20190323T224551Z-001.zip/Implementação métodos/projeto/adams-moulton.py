from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

x, y, z, t, r = symbols('x y z t r')

yo = 1
to = 0
h = 0.05
n = 40
expr = 1 - t + 4*y
Beta = []
s=4
res=1

for j in range(s+1):
    for k in range(s+1):
        if(k!=j):
            res = res * (r+s-k-1)
    aux = ((-1)**(s-j))/(factorial(j)*factorial(s-j))
    aux2 = integrate(res,(r,0,1))
    Beta.append(aux*aux2)
    res=1
print(Beta)

def adamsBB(Beta,yn):
    auxBeta = 0
    for i in range(s):
        auxBeta = auxBeta + Beta[i]*(expr.subs([(y, yo), (t, to)]))
    return auxBeta

def adamsB(auxBeta):
    ys[s] = ys[s-1] + h*(auxBeta)



