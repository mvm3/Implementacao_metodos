from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

def proj_euler(yo,to,h,n,expr):
    axesT = [to]
    axesY = [yo]
    print(0,yo)
    for i in range(n):
        k1 = expr.subs([(y, yo), (t, to)])
        yo = yo + (h*k1)
        to = to + h
        axesY.append(yo)
        axesT.append(to)
        print(i+1,yo)
    print('\n')
    plt.plot(axesT,axesY)
    plt.show()

def eulerAux(yeu,to,h,n,expr):
    yo=[]
    yo.append(yeu)
    for i in range(n):
        k1 = expr.subs([(y, yeu), (t, to)])
        yeu = yeu + (h*k1)
        yo.append(yeu)
        to = to + h
    return yo

def proj_euler_inverso(yo,to,h,n,expr):
    axesT = [to]
    axesY = [yo]
    print(0,yo)
    for i in range(n):
        to = to + h
        exprAux = expr.subs(t, to)
        yn = yo + h*(exprAux)
        k1 = yn - y
        sol = solve(k1, y)
        yo = sol[0]
        print(i+1,yo)
        axesY.append(yo)
        axesT.append(to)
    print('\n')
    plt.plot(axesT,axesT)
    plt.show()

def euler_inversoAux(yeu,to,h,n,expr):
    yo=[]
    yo.append(yeu)
    for i in range(n):
        to = to + h
        exprAux = expr.subs(t, to)
        yn = yeu + h*(exprAux)
        k1 = yn - y
        sol = solve(k1, y)
        yeu = sol[0]
        yo.append(yeu)
    return yo

def proj_euler_ap(yo,to,h,n,expr):
    axesT = [to]
    axesY = [yo]
    print(0,yo)
    for i in range(n):
        exprAux = expr.subs([(y, yo), (t, to)])
        exprAux2 = expr.subs(t, to + h)
        yn = yo + (h/2)*(exprAux + exprAux2)
        k1 = yn - y
        sol = solve(k1, y)
        yo = sol[0]
        print(i+1,yo)
        to = to + h
        axesY.append(yo)
        axesT.append(to)
    print('\n')
    plt.plot(axesT,axesT)
    plt.show()

def euler_apAux(yeu,to,h,n,expr):
    yo=[]
    yo.append(yeu)
    for i in range(n):
        exprAux = expr.subs([(y, yeu), (t, to)])
        exprAux2 = expr.subs(t, to + h)
        yn = yeu + (h/2)*(exprAux + exprAux2)
        k1 = yn - y
        sol = solve(k1, y)
        yeu = sol[0]
        to = to + h
        yo.append(yeu)
    return yo

def proj_runge_kutta(yo,to,h,n,expr):
    axesT = [to]
    axesY = [yo]
    print(0,yo)
    for i in range(n):
        kn1= expr.subs([(y, yo), (t, to)])
        kn2= expr.subs([(y, yo + (h/2)*kn1), (t, to + (h/2))])
        kn3= expr.subs([(y, yo + (h/2)*kn2), (t, to + (h/2))])
        kn4= expr.subs([(y, yo + h*kn3), (t, to + h)])
        yn = yo + (h/6)*(kn1 + 2*kn2 + 2*kn3 + kn4)
        yo = yn
        to = to + h
        axesY.append(yo)
        axesT.append(to)
        print(i+1,yo)
    plt.plot(axesT,axesY)
    plt.show()
    print('\n')

def runge_kuttaAux(yeu,to,h,n,expr):
    yo=[]
    yo.append(yeu)
    for i in range(n):
        kn1= expr.subs([(y, yeu), (t, to)])
        kn2= expr.subs([(y, yeu + (h/2)*kn1), (t, to + (h/2))])
        kn3= expr.subs([(y, yeu + (h/2)*kn2), (t, to + (h/2))])
        kn4= expr.subs([(y, yeu + h*kn3), (t, to + h)])
        yn = yeu + (h/6)*(kn1 + 2*kn2 + 2*kn3 + kn4)
        yeu = yn
        to = to + h
        yo.append(yeu)
    return yo

def proj_runge_kutta_5(yo,to,h,n,expr):
    axesT = [to]
    axesY = [yo]
    print(0,yo)
    for i in range(n):
        kn1= expr.subs([(y, yo), (t, to)])
        kn2= expr.subs([(y, yo + (h/4)*kn1), (t, to + (h/4))])
        kn3= expr.subs([(y, yo + (h/8)*kn1 + (h/8)*kn2), (t, to + (h/4))])
        kn4= expr.subs([(y, yo -((h/2)*kn2) + h*kn3), (t, to + (h/2))])
        kn5 = expr.subs([(y, yo + (h/16)*3*kn1 + (h/16)*9*kn4), (t, to + (h/4)*3)])
        kn6 = expr.subs([(y, yo -((3/7)*h*kn1) + (2/7)*h*kn2 + (12/7)*h*kn3 -((12/7)*h*kn4) + (8/7)*h*kn5), (t, to + h)])
        yn = yo + (h/90)*(7*kn1 + 32*kn3 + 12*kn4 + 32*kn5 + 7*kn6)
        yo = yn
        to = to + h
        axesY.append(yo)
        axesT.append(to)
        print(i+1,yo)
    plt.plot(axesT,axesY)
    plt.show()

def proj_adams_bashforth(yo,to,h,n,expr,s):
    axesT = []
    axesY = []
    Beta = []
    res=1
    for j in range(s):
        for k in range(s):
            if(k!=j):
                res = res * (r+s-k-1)
        aux = ((-1)**(s-j-1))/(factorial(j)*factorial(s-j-1))
        aux2 = integrate(res,(r,0,1))
        Beta.append((aux)*(aux2))
        res=1  
    for p in range(s):
        print(p,yo[p])
        axesY.append(yo[p])
        axesT.append(to+(h*p))
    for w in range(n-s+1):##15 int
        fAux=0
        for i in range(s):
            fAux = fAux + (Beta[i]*(expr.subs([(y, yo[i+w]), (t, to + h*(i+w))])))
        yAux=yo[len(yo)-1] + h*(fAux)
        axesY.append(yAux)
        axesT.append(to + h*(i+w+1))
        print(w+i+1,yAux)
        yo.append(yAux)
    print('\n')
    plt.plot(axesT,axesY)
    plt.show()

with open('entrada.txt') as file:
    for line in file:
        line = line.split(" ")
        if(line[0]=="euler"):
            print('Metodo de Euler\n'+'y['+line[2]+'] = '+ line[1])
            print('h = '+line[3])
            yo=float(line[1])
            to=float(line[2])
            h=float(line[3])
            n=int(line[4])
            y, t = symbols('y t')
            expr=sympify(line[5])
            proj_euler(yo,to,h,n,expr)
        if(line[0]=="euler_inverso"):
            print('Metodo de Euler Inverso\n'+'y['+line[2]+'] = '+ line[1])
            print('h = '+line[3])
            yo=float(line[1])
            to=float(line[2])
            h=float(line[3])
            n=int(line[4])
            y, t = symbols('y t')
            expr=sympify(line[5])
            proj_euler_inverso(yo,to,h,n,expr)
        if(line[0]=="euler_aprimorado"):
            print('Metodo de Euler Aprimorado\n'+'y['+line[2]+'] = '+ line[1])
            print('h = '+line[3])
            yo=float(line[1])
            to=float(line[2])
            h=float(line[3])
            n=int(line[4])
            y, t = symbols('y t')
            expr=sympify(line[5])
            proj_euler_ap(yo,to,h,n,expr)
        if(line[0]=="runge_kutta"):
            print('Metodo de Runge-Kutta\n'+'y['+line[2]+'] = '+ line[1])
            print('h = '+line[3])
            yo=float(line[1])
            to=float(line[2])
            h=float(line[3])
            n=int(line[4])
            y, t = symbols('y t')
            expr=sympify(line[5])
            proj_runge_kutta(yo,to,h,n,expr)
        if(line[0]=="adam_bashforth"):
            s=int(line[len(line)-1])
            yo=[]
            for q in range(s):
                yo.append(float(line[q+1]))
            print('Metodo de Adan-Bashforth\n'+'y['+line[s+1]+'] = '+ line[1])
            print('h = '+line[s+2])
            to=float(line[s+1])
            h=float(line[s+2])
            n=int(line[s+3])
            y, t, r = symbols('y t r')
            expr=sympify(line[s+4])
            proj_adams_bashforth(yo,to,h,n,expr,s)
        if(line[0]=="adam_bashforth_by_euler"):
            s=int(line[len(line)-1])
            print('Metodo de Adan-Bashforth por Euler\n'+'y['+line[2]+'] = '+ line[1])
            print('h = '+line[3])
            yeu=(float(line[1]))
            to=float(line[2])
            h=float(line[3])
            n=int(line[4])
            y, t, r = symbols('y t r')
            expr=sympify(line[5])
            yo=eulerAux(yeu,to,h,s-1,expr)
            proj_adams_bashforth(yo,to,h,n,expr,s)
        if(line[0]=="adam_bashforth_by_euler_inverso"):
            s=int(line[len(line)-1])
            print('Metodo de Adan-Bashforth por Euler Inverso\n'+'y['+line[2]+'] = '+ line[1])
            print('h = '+line[3])
            yeu=(float(line[1]))
            to=float(line[2])
            h=float(line[3])
            n=int(line[4])
            y, t, r = symbols('y t r')
            expr=sympify(line[5])
            yo=euler_inversoAux(yeu,to,h,s-1,expr)
            proj_adams_bashforth(yo,to,h,n,expr,s)
        if(line[0]=="adam_bashforth_by_euler_aprimorado"):
            s=int(line[len(line)-1])
            print('Metodo de Adan-Bashforth por Euler Aprimorado\n'+'y['+line[2]+'] = '+ line[1])
            print('h = '+line[3])
            yeu=(float(line[1]))
            to=float(line[2])
            h=float(line[3])
            n=int(line[4])
            y, t, r = symbols('y t r')
            expr=sympify(line[5])
            yo=euler_apAux(yeu,to,h,s-1,expr)
            proj_adams_bashforth(yo,to,h,n,expr,s)
        if(line[0]=="adam_bashforth_by_runge_kutta"):
            s=int(line[len(line)-1])
            print('Metodo de Adan-Bashforth por Runge-Kutta\n'+'y['+line[2]+'] = '+ line[1])
            print('h = '+line[3])
            yeu=(float(line[1]))
            to=float(line[2])
            h=float(line[3])
            n=int(line[4])
            y, t, r = symbols('y t r')
            expr=sympify(line[5])
            yo=runge_kuttaAux(yeu,to,h,s-1,expr)
            proj_adams_bashforth(yo,to,h,n,expr,s)
