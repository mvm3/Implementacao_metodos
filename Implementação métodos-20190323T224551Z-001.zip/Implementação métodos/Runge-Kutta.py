from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

x, y, z, t = symbols('x y z t')

yo = 1
to = 0
h = 0.05
n = 40
expr = 1 - t + 4*y
axest = [to]
axesy = [yo]

for i in range(n):
    kn1= expr.subs([(y, yo), (t, to)])
    kn2= expr.subs([(y, yo + (h/2)*kn1), (t, to + (h/2))])
    kn3= expr.subs([(y, yo + (h/2)*kn2), (t, to + (h/2))])
    kn4= expr.subs([(y, yo + h*kn3), (t, to + h)])
    yn = yo + (h/6)*(kn1 + 2*kn2 + 2*kn3 + kn4)
    yo = yn
    axesy.append(yo)
    axest.append(to)
    to = to + h
    print(yo)

plt.plot(axest,axesy)
plt.show()