from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

x, y, z, t = symbols('x y z t')

yo = 1
to = 0
h = 0.05
n = 40
expr = 1 - t + 4*y
axest = [to]
axesy = [yo]

for i in range(n):
    kn1= expr.subs([(y, yo), (t, to)])
    kn2= expr.subs([(y, yo + (h/4)*kn1), (t, to + (h/4))])
    kn3= expr.subs([(y, yo + (h/8)*kn1 + (h/8)*kn2), (t, to + (h/4))])
    kn4= expr.subs([(y, yo -((h/2)*kn2) + h*kn3), (t, to + (h/2))])
    kn5 = expr.subs([(y, yo + (h/16)*3*kn1 + (h/16)*9*kn4), (t, to + (h/4)*3)])

    kn6 = expr.subs([(y, yo -((3/7)*h*kn1) + (2/7)*h*kn2 + (12/7)*h*kn3 -((12/7)*h*kn4) + (8/7)*h*kn5), (t, to + h)])

    yn = yo + (h/90)*(7*kn1 + 32*kn3 + 12*kn4 + 32*kn5 + 7*kn6)
    yo = yn
    axesy.append(yo)
    axest.append(to)
    to = to + h
    print(yo)

plt.plot(axest,axesy)
plt.show()