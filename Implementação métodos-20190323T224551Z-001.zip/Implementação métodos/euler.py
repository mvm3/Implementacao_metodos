from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

x, y, z, t = symbols('x y z t')

yo = 1
to = 0
h = 0.001
n = 2000
expr = 1 - t + 4*y
axest = [to]
axesy = [yo]

for i in range(n):
    k1 = expr.subs([(y, yo), (t, to)])
    yo = yo + (h*k1)
    to = to + h
    axesy.append(yo)
    axest.append(to)

plt.plot(axest,axesy)
plt.show()