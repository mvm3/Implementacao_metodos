from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

x, y, z, t, r = symbols('x y z t r')
#f1 = open("entrada.txt", "r")
#f2 = open("saida.txt", "w")
#l = f.readline().split()
#y=int(float(l[0]))
#adam_bashforth 0.0 0.1 0.23 0.402 0.6328 0 0.1 20 1-t+4*y 5
yo = [0.0, 0.1, 0.23, 0.402, 0.6328]
to = 0
h = 0.1
n = 20
expr = 1-t+4*y
s=5
Beta = []
res=1

for j in range(s):
    for k in range(s):
        if(k!=j):
            res = res * (r+s-k-1)
    aux = ((-1)**(s-j-1))/(factorial(j)*factorial(s-j-1))
    aux2 = integrate(res,(r,0,1))
    Beta.append((aux)*(aux2))
    res=1
#print(Beta)
for w in range(n-s+1):##15 int
    fAux=0
    for i in range(s):
        fAux = fAux + (Beta[i]*(expr.subs([(y, yo[i+w]), (t, to + h*(i+w))])))
    yAux=yo[len(yo)-1] + h*(fAux)
    print(yAux)
    yo.append(yAux)
        
