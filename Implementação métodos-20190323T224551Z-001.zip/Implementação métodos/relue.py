from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

x, y, z, t = symbols('x y z t')

yo = 1
to = 0
h = 0.01
n = 200
expr = 1 - t + 4*y
axest = [to]
axesy = [yo]

for i in range(n):
    to = to + h
    exprAux = expr.subs(t, to)
    yn = yo + h*(exprAux)
    k1 = yn - y
    sol = solve(k1, y)
    yo = sol[0]
    print(yo)
    axesy.append(yo)
    axest.append(to - h)

plt.plot(axest,axesy)
plt.show()