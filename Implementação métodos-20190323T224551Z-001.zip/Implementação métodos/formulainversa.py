from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

k = 4
t, y = symbols('t y')
ysym = list(symbols('y0:%d'%k))
ysym.append(y)

yn=[1, 1.6089333, 2.5050062, 3.8294145]
to = 0
h = 0.1
n=20
expr = 1-t+4*y
j = 1
resulT = 0
axesT = []
axesY = []
while j <= k:
    i = 0
    sumT = 0
    while i <= j:
        sumT = sumT + ((-1)**i)*binomial(j,i)*ysym[len(ysym)-1-i]
        i += 1
    resulT = resulT + (1/(j))*sumT
    j += 1
for p in range(k):
    print(p,yn[p])
    axesY.append(yn[p])
    axesT.append(to+(h*p))
for w in range(n-k+1):
    j=0
    auxRes = resulT
    for i in yn:
        auxRes = auxRes.subs([(ysym[j], i)])
        j+=1
    auxRes = Eq(auxRes, h*(expr.subs(t, to+h*(k+w))))
    auxRes = solve(auxRes, y)
    auxRes = auxRes[0]
    print(w+k,auxRes)
    axesY.append(auxRes)
    axesT.append(to + h*(k+w))
    yn.append(auxRes)
    yn.pop(0)
    
print('\n')
plt.plot(axesT,axesY)
plt.show()