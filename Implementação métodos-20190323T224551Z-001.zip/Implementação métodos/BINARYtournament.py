from __future__ import division ##import para fazer divisoes com float usando a '/', por ex.: 5/2 = 2.5
import random as rand
import matplotlib.pyplot as plt ##import para gerar os graficos
import numpy as np

I = [("genre","M",),("genre","F"),("age","Child"),("age","Adult"),("age","Senior"),("Medicine","A"),("Medicine","B")]

class Individual:
     def __init__(self, genre, age, medicine, label):
         self.genre = genre
         self.age = age
         self.medicine = medicine
         self.label = label
         self.fit = fit #######################adicionei ao individuo o seu valor de fitness. Facilita na seleção de torneio.

def binaryTournament(ListaIndividuos):
    ##seleciona 2 individuos aleatoriamente da população e escolhe o com maior fit, pelo menos foi isso que entendi
    ## https://stackoverflow.com/questions/36989783/binary-tournament-selection
    indv1 = rand.choice(ListaIndividuos)
    indv2 = rand.choice(ListaIndividuos)
    if(indv1.fit > indv2.fit)
        return indv1
    else
        return indv2



def WRAcc(dpi,Dmais,D):
  TP = sum([i[0] for i in dpi])
  FP = sum([i[1] for i in dpi])
  aux = ((TP + FP)/D)
  aux2 = (TP/(TP + FP)) - (Dmais/D)
  aux= aux*aux2*4

def crossover(p, crossoverRate,gen):
	for  i  in p:
		if( random.random() < crossoverRate):### ei man, aqui tu ta usando random como random sendo que tu importou como rand, tem problema?
			if (gen == 1):# AND
				p.append(p[i]+p[rand.randint(1,len(I))])
			else:#UNIFORM 
				p.append(p)
				

def mutation(p, mutationRate):
	for i in range(len(p)):
		if( rand.random() < mutationRate):
			if(len(p[i]) == 1):
				mutationType = 1
			else: 
				mutationType = rand.randint(1,3)

			if (mutationType == 1):#ADD
				p[i].append(rand.randint(1,len(I)))#resolver problema de att iguais
				#p[i].append(rand.sample(I.difference(p[i]),1))

			if (mutationType == 2):#REMOVED				
				p[i].pop(rand.randint(0,len(p[i]) - 1))

			if (mutationType == 3):#REPLACED
				p[i].pop(rand.randint(1,len(p[i]) - 1))
				p[i].append(rand.randint(1,len(I)))
				#p[i].append(rand.sample(I.difference(p[i]),1))


exemplo = []
exemplo.append([Individual("M","Senior","B","Success")])
exemplo.append([Individual("F","Senior","B","Success")])
exemplo.append([Individual("M","Senior","A","Success")])
exemplo.append([Individual("M","Adult","A","Success")])
exemplo.append([Individual("F","Child","A","Success")])
exemplo.append([Individual("F","Child","A","Failure")])
exemplo.append([Individual("M","Child","B","Failure")])
exemplo.append([Individual("F","Child","B","Failure")])
exemplo.append([Individual("M","Adult","A","Failure")])
exemplo.append([Individual("F","Adult","A","Failure")])

population = []
for i in range(len(I)):
	population.append([i+1])


print(population)
mutation(population, 0.6)
print(population)


dp = [(3, 2),(2, 3),(2, 2),(1, 2),(3,0),(3,3),(2,2)]

def kBestRelevants(k,P):

def main (k, fitnessFunc):
	P = []
	for i in range(len(I)):
		P.append([i+1])
	Pk = KBestRelevants(k,P);