from __future__ import division
from sympy import *
import numpy as np
import matplotlib.pyplot as plt

x, y, z, t = symbols('x y z t')

yo = 1
to = 0
h = 0.01
n = 200
expr = 1 - t + 4*y
axest = [to]
axesy = [yo]

for i in range(n):
    exprAux = expr.subs([(y, yo), (t, to)])
    exprAux2 = expr.subs([(y, yo + h*(exprAux)), (t, to + h)])
    yn = yo + (h/2)*(exprAux + exprAux2)
    k1 = yn - y
    sol = solve(k1, y)
    yo = sol[0]
    print(yo)
    axesy.append(yo)
    axest.append(to)
    to = to + h

plt.plot(axest,axesy)
plt.show()